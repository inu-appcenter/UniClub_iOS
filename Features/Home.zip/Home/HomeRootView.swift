//
//  HomeRootView.swift
//  UniClub
//
//  Created by 제욱 on 2/3/26.
//

import SwiftUI

struct HomeRootView: View {
    @State private var path = NavigationPath()

    var body: some View {
        NavigationStack(path: $path) {
            HomeView(
                onTapAll: { path.append(HomeRoute.clubListAll) },
                onTapCategory: { name in path.append(HomeRoute.clubListCategory(name)) },
                onTapSearch: { path.append(HomeRoute.search) }
            )
            .tabBarPresent(true)
            .navigationDestination(for: HomeRoute.self) { route in
                switch route {
                case .clubListAll:
                    ClubListView(mode: .all, onTapSearch: { path.append(HomeRoute.search) })
                        .tabBarPresent(false)

                case .clubListCategory(let name):
                    ClubListView(mode: .category(name), onTapSearch: { path.append(HomeRoute.search) })
                        .tabBarPresent(false)

                case .search:
                    SearchView()
                        .tabBarPresent(false)
                }
            }
        }
    }
}
