//  MainClubsService.swift
//  UniClub
//
//  Created by 제욱 on 2/8/26.
//

import Foundation

// GET /api/v1/main/clubs 응답 스키마에 맞춘 모델
struct MainClubItem: Identifiable, Decodable {
    let clubId: Int
    let name: String
    let imageUrl: URL?      // ✅ null 허용
    let favorite: Bool

    var id: Int { clubId }
}

enum MainClubsService {
    /// GET /api/v1/main/clubs
    /// - Note: favorite가 사용자별이라 Authorization이 필요할 가능성이 높음
    static func fetchMainClubs() async throws -> [MainClubItem] {
        let url = AppConfig.baseURL.appendingPathComponent(
            AppConfig.API.Main.clubs.trimmingCharacters(in: CharacterSet(charactersIn: "/"))
        )

        var req = URLRequest(url: url)
        req.httpMethod = "GET"
        req.setValue("application/json", forHTTPHeaderField: "Accept")

        let (data, resp) = try await HTTPClient.shared.sendRaw(req, requiresAuth: true)

        guard let http = resp as? HTTPURLResponse else {
            throw APIError.badResponse(-1, "Invalid HTTPURLResponse")
        }

        guard (200...299).contains(http.statusCode) else {
            let body = String(data: data, encoding: .utf8) ?? ""
            throw APIError.badResponse(http.statusCode, body)
        }

        let dec = JSONDecoder()
        return try dec.decode([MainClubItem].self, from: data)
    }
}
